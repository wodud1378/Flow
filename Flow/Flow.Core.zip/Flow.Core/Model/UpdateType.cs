namespace Flow.Core.Model
{
    public enum UpdateType
    {
        Update,
        FixedUpdate,
        LateUpdate,
    }
}