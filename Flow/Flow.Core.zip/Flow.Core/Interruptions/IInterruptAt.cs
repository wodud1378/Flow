namespace Flow.Core.Interruptions
{
    public interface IInterruptAt { }
}