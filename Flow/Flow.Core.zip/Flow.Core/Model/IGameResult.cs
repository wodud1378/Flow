﻿namespace Flow.Core.Model
{
    public interface IGameResult
    {
        public int Score { get; }
        public bool Win { get; }
    }
}