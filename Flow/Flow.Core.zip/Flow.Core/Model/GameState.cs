﻿namespace Flow.Core.Model
{
    public enum GameState
    {
        Undefined,
        Initialization,
        Running,
        End,
    }
}